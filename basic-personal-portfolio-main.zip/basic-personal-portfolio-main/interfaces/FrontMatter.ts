export default interface FrontMatter {
  title: string;
  publishedAt: number;
}
